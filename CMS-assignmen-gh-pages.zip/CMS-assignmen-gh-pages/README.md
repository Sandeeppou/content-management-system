# cp3402-group-1
This is Group 1 Documentations that will help new users or users who know how work with Wordpress by following these 3 files which are:

* [Theme.md](Theme.md)
* [Development.md](Deployment.md)
* [Site.md](Site.md)


The following file called  [a2.html] will have these inside which are:

* Names of the members with their LinkedIn accounts and Github accounts.
* Goals of the webiste.
* Project links to the production and staging site, Github repository, Project board and a communication platform we used to chat with each other.
* Login in details for Wordpress for both the Production and Staging site.


The custom theme for this Project is called jcub-home-finder and it is in main repository or you can download it from this repository.

* [GITHUB Environment](https://github.com/PhucLanPhan/CMS-assignmen.git)

This is a link to our Production Site: https://jcubhomefindercom.stage.site/

This is a link to our video Presentation for Group 1:
* 
